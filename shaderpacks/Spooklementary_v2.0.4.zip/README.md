# <img src="https://cdn-raw.modrinth.com/data/6uJCfiCH/0b4983e0ba8cac6ffe2cc5c2076a8a6b0b28fd1f.png" alt="Spooklementary_logo" width="60" height="auto" /> &nbsp; Spooklementary

<a href="https://discord.gg/5N45SAsC3X" target="_blank">
<img alt="Static Badge" src="https://img.shields.io/badge/discord-white?style=for-the-badge&logo=discord&logoColor=rgb(210%2C%20106%2C%206)&label=join&labelColor=rgb(4%2C%2011%2C%2020)&color=rgb(210%2C%20106%2C%206)">
</a>
&nbsp;
<img alt="Static Badge" src="https://img.shields.io/badge/iris%2C%20optifine%2C%20oculus%20%7C%201.7.10%20to%20Latest-white?style=for-the-badge&logo=modrinth&label=SUPPORTS&labelColor=rgb(4%2C%2011%2C%2020)&color=rgb(210%2C%20106%2C%206)">
&nbsp;
<a href="https://www.patreon.com/SpacEagle17" target="_blank">
<img alt="Static Badge" src="https://img.shields.io/badge/spaceagle17-white?style=for-the-badge&logo=patreon&logoColor=rgb(210%2C%20106%2C%206)&label=SUPPORT&labelColor=rgb(4%2C%2011%2C%2020)&color=rgb(210%2C%20106%2C%206)&link=https%3A%2F%2Fpatreon.com%2Fspaceagle17">
</a>

## What is Spooklementary?

* Spooklementary, by SpacEagle17, is an edit of EminGT's [Complementary Shaders](https://www.complementary.dev/). 
* It is a horror-themed shaderpack that transforms your game into a moody and spooky experience.
* Perfect for Halloween or scary maps! Click "Gallery" at the top of the page to see screenshots.

**Important notice: Please don't report any bugs while using this add-on to Emin, but to me instead on [Discord](https://discord.gg/5N45SAsC3X).**

## Links
<center>
<div style="text-align: center;" align="center">
  <a href="https://www.patreon.com/SpacEagle17" rel="nofollow">
    <img src="https://cdn.modrinth.com/data/cached_images/7f94a4d0b4854a694e1b3dbb5aa8e42fc15bce89.png" alt="Patreon" />
    <br><br>
  </a>
</div>
</center>

* SpacEagle17's **[<ins>Discord</ins>](https://discord.gg/5N45SAsC3X)** Server for discussion, questions, suggestions...
* Follow SpacEagle17 on **[<ins>Twitter/X</ins>](https://twitter.com/SpacEagle17)** to get news about the shaderpack

[![IMAGE ALT TEXT HERE](https://github.com/user-attachments/assets/3882d6dc-a7cd-4f2b-9e11-fc85d65c7d86)](https://www.youtube.com/watch?v=CndrX1R5boQ)

## Sponsored by Ember Host
Looking for an affordable and reliable Minecraft server host? Ember Host offers incredible value and top-tier support!

Click the banner or use code **[EUPHORIA](https://www.euphoriapatches.com/ember-referral)** at checkout for **10%** off your first purchase. Plus, **70%** of your purchase supports Euphoria Patches!

<a href="https://www.euphoriapatches.com/ember-referral"><img src=https://cdn.modrinth.com/data/cached_images/545bcc6a4800cae3bace3a58a06e0dab9eccf9e4_0.webp></a>
